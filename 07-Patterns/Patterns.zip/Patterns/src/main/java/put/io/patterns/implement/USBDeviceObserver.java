package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver {

    private int numberOfUSBDevices;

    public USBDeviceObserver(SystemMonitor monitor) {
        this.numberOfUSBDevices = monitor.getLastSystemState().getUsbDevices();
    }

    @Override
    public void update(SystemMonitor monitor) {
        // Detects the change in the number of USB devices.
        int numUSB = monitor.getLastSystemState().getUsbDevices();
        if ( numUSB != this.numberOfUSBDevices) {
            System.out.println("Number of USB devices has changed!");
            this.numberOfUSBDevices = numUSB;
        }
    }
}
